// ignore_for_file: file_names

class Globle {
  //
  static bool youTube = false;

  static List<Map> songs = [
    {
      "id": 1,
      "Name": "Love Me Like You Do",
      "path": "love.m4a",
    },
    {
      "id": 2,
      "Name": "Unknown",
      "path": "1.m4a",
    },
    {
      "id": 3,
      "Name": "ZAYN_Dusk",
      "path": "ZAYN_-_Dusk_Till_Dawn.m4a",
    },
    {
      "id": 4,
      "Name": "Ok_Jaanu_X_Heat_Waves",
      "path": "Ok_Jaanu_X_Heat_Waves__Lyrics___Mashup.m4a",
    },
    {
      "id": 5,
      "Name": "Gym_Class_Heroes__Stereo_Hearts",
      "path": "Gym_Class_Heroes__Stereo_Hearts_ft.m4a",
    },
    {
      "id": 6,
      "Name": "Glass_Animals-Heat_Waves",
      "path": "Glass_Animals-Heat_Waves.m4a",
    },
    {
      "id": 7,
      "Name": "Shay_Justin_Bieber",
      "path": "Shay_Justin_Bieber.m4a",
    },
    {
      "id": 8,
      "Name": "Coldplay",
      "path": "Coldplay.mp3",
    },
    {
      "id": 9,
      "Name": "Bollywood_Lofi_Mixtape",
      "path": "Bollywood_Lofi_Mixtape.m4a",
    },
  ];

  static List<Map> youTubeList = [
    {
      "Name": "Bee",
      "path":
          "https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4",
    },
    {
      "Name": "Big_Buck_Bunny",
      "path":
          "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4",
    },
    {
      "Name": "Small-flowering-plants-in-a-nursery",
      "path":
          "https://assets.mixkit.co/videos/preview/mixkit-small-flowering-plants-in-a-nursery-43709-large.mp4",
    },
    {
      "Name": "Going-down-a-curved-highway-through-a-mountain-range",
      "path":
          "https://assets.mixkit.co/videos/preview/mixkit-going-down-a-curved-highway-through-a-mountain-range-41576-large.mp4",
    },
    {
      "Name": "Stars-in-space",
      "path":
          "https://assets.mixkit.co/videos/preview/mixkit-stars-in-space-background-1610-large.mp4",
    },
    {
      "Name": "Stunning-sunset-seen-from-the-sea",
      "path":
          "https://assets.mixkit.co/videos/preview/mixkit-stunning-sunset-seen-from-the-sea-4119-large.mp4",
    },
    {
      "Name": "People-pouring-a-warm-drink-around-a-campfire",
      "path":
          "https://assets.mixkit.co/videos/preview/mixkit-people-pouring-a-warm-drink-around-a-campfire-513-large.mp4",
    },
    {
      "Name": "Portrait-of-a-jugglery-woman-making-a-fire-hoop",
      "path":
          "https://assets.mixkit.co/videos/preview/mixkit-portrait-of-a-jugglery-woman-making-a-fire-hoop-43681-large.mp4",
    },
    {
      "Name": "Hands-of-a-man-playing-on-a-computer",
      "path":
          "https://assets.mixkit.co/videos/preview/mixkit-hands-of-a-man-playing-on-a-computer-43527-large.mp4",
    },
    {
      "Name": "Hands-of-a-skilled-musician-playing-the-piano",
      "path":
          "https://assets.mixkit.co/videos/preview/mixkit-hands-of-a-skilled-musician-playing-the-piano-43776-large.mp4",
    },
    {
      "Name": "Fireworks-illuminating-the-beach-sky",
      "path":
          "https://assets.mixkit.co/videos/preview/mixkit-fireworks-illuminating-the-beach-sky-4157-large.mp4",
    },
    {
      "Name": "Fireworks-illuminating-the-beach-sky",
      "path":
          "https://assets.mixkit.co/videos/preview/mixkit-fireworks-illuminating-the-beach-sky-4157-large.mp4",
    },
    {
      "Name": "Lake-surrounded-by-dry-grass-in-the-savanna",
      "path":
          "https://mixkit.imgix.net/videos/preview/mixkit-lake-surrounded-by-dry-grass-in-the-savanna-5030-0.jpg?q=80&auto=format%2Ccompress&w=460",
    },
  ];

  static List imageYouTube = [];

  static List images = [
    "assets/images/ahmed.jpg",
    "assets/images/water.jpg",
    "assets/images/sunset.jpg",
    "assets/images/waterfall.jpg",
    "assets/images/nature.jpg",
    "assets/images/dear.jpg",
    "assets/images/malik.jpg",
    "assets/images/bulding.jpg",
    "assets/images/two.jpg",
  ];
}
