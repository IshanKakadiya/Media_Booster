// ignore_for_file: camel_case_types, unused_local_variable, no_leading_underscores_for_local_identifiers

import 'package:audio_application/Globle.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class Slider_Page extends StatefulWidget {
  const Slider_Page({Key? key}) : super(key: key);

  @override
  State<Slider_Page> createState() => _Slider_PageState();
}

class _Slider_PageState extends State<Slider_Page> {
  CarouselController carouselController = CarouselController();
  int currentindex = 0;
  bool toggleSlider = true;

  @override
  Widget build(BuildContext context) {
    double _height = MediaQuery.of(context).size.height;
    double _width = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Slider App"),
        centerTitle: true,
        actions: [
          Switch(
              value: toggleSlider,
              onChanged: (val) {
                setState(() {
                  toggleSlider = val;
                });
              }),
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CarouselSlider(
            carouselController: carouselController,
            options: CarouselOptions(
                autoPlay: true,
                autoPlayAnimationDuration: const Duration(milliseconds: 700),
                autoPlayCurve: Curves.easeInOut,
                autoPlayInterval: const Duration(seconds: 2),
                scrollPhysics: const BouncingScrollPhysics(),
                scrollDirection:
                    (toggleSlider) ? Axis.horizontal : Axis.vertical,
                height: (toggleSlider) ? 300 : 400,
                viewportFraction: (toggleSlider) ? 0.8 : 0.8,
                enlargeCenterPage: true,
                initialPage: currentindex,
                onPageChanged: (val, _) {
                  setState(() {
                    currentindex = val;
                  });
                }),
            items: Globle.images
                .map(
                  (e) => Container(
                    width: _width,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        fit: BoxFit.cover,
                        image: AssetImage(e),
                      ),
                    ),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 40),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: Globle.images.map((e) {
              int i = Globle.images.indexOf(e);

              return Row(
                children: [
                  GestureDetector(
                    child: CircleAvatar(
                      radius: 4,
                      backgroundColor: (currentindex == i)
                          ? Colors.white
                          : Colors.white.withOpacity(0.2),
                    ),
                    onTap: () {
                      carouselController.animateToPage(i);
                      setState(() {
                        currentindex = i;
                      });
                    },
                  ),
                  const SizedBox(width: 7),
                ],
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
