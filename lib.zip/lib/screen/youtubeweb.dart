// ignore_for_file: camel_case_types, unused_local_variable

import 'package:audio_application/Globle.dart';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';

class YouTubeWeb_Page extends StatefulWidget {
  const YouTubeWeb_Page({Key? key}) : super(key: key);

  @override
  State<YouTubeWeb_Page> createState() => _YouTubeWeb_PageState();
}

class _YouTubeWeb_PageState extends State<YouTubeWeb_Page> {
  late ChewieController chewieController;

  @override
  Widget build(BuildContext context) {
    dynamic res = ModalRoute.of(context)!.settings.arguments;

    chewieController = ChewieController(
      videoPlayerController: Globle.imageYouTube[res],
      autoPlay: true,
      looping: false,
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text("Video Playing"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop();
            Globle.imageYouTube[res].pause();
          },
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            (Globle.imageYouTube[res].value.isInitialized)
                ? AspectRatio(
                    aspectRatio: Globle.imageYouTube[res].value.aspectRatio,
                    child: Chewie(controller: chewieController),
                  )
                : const Center(
                    child: CircularProgressIndicator(),
                  ),
          ],
        ),
      ),
    );
  }
}
