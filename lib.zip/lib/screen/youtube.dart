// ignore_for_file: camel_case_types, unused_local_variable, no_leading_underscores_for_local_identifiers

import 'package:audio_application/Globle.dart';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class Video_Player_Page extends StatefulWidget {
  const Video_Player_Page({Key? key}) : super(key: key);

  @override
  State<Video_Player_Page> createState() => _Video_Player_PageState();
}

class _Video_Player_PageState extends State<Video_Player_Page> {
  late VideoPlayerController videoPlayerController;
  late ChewieController chewieController;

  @override
  void initState() {
    super.initState();
    imageLoad();
  }

  @override
  void dispose() {
    videoPlayerController.dispose();
    chewieController.dispose();
    super.dispose();
  }

  int index = 9;

  @override
  Widget build(BuildContext context) {
    double _height = MediaQuery.of(context).size.height;
    double _width = MediaQuery.of(context).size.width;

    (Globle.youTube)
        ? null
        : chewieController = ChewieController(
            videoPlayerController: Globle.imageYouTube[index],
            autoPlay: false,
            looping: false,
          );

    return (Globle.youTube)
        ? Scaffold(
            appBar: AppBar(
              title: const Text("YouTube Website"),
              actions: [
                Switch(
                  value: Globle.youTube,
                  onChanged: (val) {
                    setState(() {
                      Globle.youTube = val;
                    });
                  },
                ),
                const SizedBox(width: 10),
              ],
            ),
            body: ListView.separated(
              padding: const EdgeInsets.all(5),
              physics: const BouncingScrollPhysics(),
              itemCount: Globle.youTubeList.length,
              separatorBuilder: (context, i) => const SizedBox(height: 0),
              itemBuilder: (context, i) => InkWell(
                onTap: () {
                  Navigator.of(context)
                      .pushNamed("YouTubeWeb_Page", arguments: i);
                },
                child: Container(
                  height: _height * 0.15,
                  width: _width,
                  // color: Colors.red,
                  padding: const EdgeInsets.all(10),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        height: 100,
                        width: 160,
                        color: Colors.white,
                        child: VideoPlayer(Globle.imageYouTube[i]),
                      ),
                      const SizedBox(width: 15),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: 155,
                            child: Text(
                              "${Globle.youTubeList[i]["Name"]}",
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const SizedBox(height: 7),
                          Row(
                            children: [
                              const CircleAvatar(
                                radius: 7,
                                backgroundColor: Colors.grey,
                                child: Icon(
                                  Icons.download_done_sharp,
                                  size: 10,
                                ),
                              ),
                              const SizedBox(width: 10),
                              SizedBox(
                                width: 131,
                                child: Text(
                                  "Ishan Kakadiya",
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      color: Colors.white.withOpacity(0.5)),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          SizedBox(
                            width: 155,
                            child: Text(
                              "9.7K views - 2 years ago",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.5),
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          )
        : Scaffold(
            appBar: AppBar(
              title: const Text("YouTube"),
              actions: [
                Switch(
                  value: Globle.youTube,
                  onChanged: (val) {
                    setState(() {
                      Globle.youTube = val;
                    });
                  },
                ),
                const SizedBox(width: 10),
              ],
            ),
            body: ListView.separated(
              itemCount: Globle.youTubeList.length,
              // padding: const EdgeInsets.all(10),
              physics: const BouncingScrollPhysics(),
              separatorBuilder: (context, i) => const SizedBox(height: 5),
              itemBuilder: (context, i) => InkWell(
                onTap: () {
                  setState(() {
                    index = i;
                    chewieController = ChewieController(
                      videoPlayerController: Globle.imageYouTube[i],
                      autoPlay: true,
                      looping: false,
                    );
                  });
                },
                child: Container(
                  height: _height / 3,
                  width: _width,
                  color: Colors.black.withOpacity(0.1),
                  // padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 200,
                        width: _width,
                        child: (i == index)
                            ? (Globle.imageYouTube[i].value.isInitialized)
                                ? AspectRatio(
                                    aspectRatio: Globle
                                        .imageYouTube[i].value.aspectRatio,
                                    child: (index == i)
                                        ? Chewie(controller: chewieController)
                                        : null,
                                  )
                                : const Center(
                                    child: CircularProgressIndicator(),
                                  )
                            : VideoPlayer(Globle.imageYouTube[i]),
                      ),
                      const SizedBox(height: 9),
                      Row(
                        children: [
                          const SizedBox(width: 7),
                          const CircleAvatar(
                            radius: 20,
                          ),
                          const SizedBox(width: 13),
                          SizedBox(
                            width: 275,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "${Globle.youTubeList[i]["Name"]}",
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  "Ishan Kakadiya - 3.3M views - 2 days ago",
                                  style: TextStyle(
                                      color: Colors.white.withOpacity(0.7)),
                                ),
                              ],
                            ),
                          ),
                          const Spacer(),
                          const Icon(Icons.more_vert, size: 20),
                          const SizedBox(width: 5),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
  }

  imageLoad() {
    for (int i = 0; i < Globle.youTubeList.length; i++) {
      videoPlayerController =
          VideoPlayerController.network("${Globle.youTubeList[i]["path"]}")
            ..initialize().then((value) => setState(() {}));

      Globle.imageYouTube.add(videoPlayerController);
    }
  }
}
