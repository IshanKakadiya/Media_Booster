// ignore_for_file: depend_on_referenced_packages

import 'package:audio_application/screen/Audio_Player.dart';
import 'package:audio_application/screen/slider.dart';
import 'package:audio_application/screen/youtube.dart';
import 'package:audio_application/screen/youtubeweb.dart';
import 'package:flutter/material.dart';
import 'package:assets_audio_player/assets_audio_player.dart';

void main() {
  runApp(
    MaterialApp(
      theme: ThemeData.dark(),
      debugShowCheckedModeBanner: false,
      routes: {
        "/": (context) => const MyApp(),
        "AudioPlayerPage": (context) => const AudioPlayerPage(),
        "Video_Player_Page": (context) => const Video_Player_Page(),
        "YouTubeWeb_Page": (context) => const YouTubeWeb_Page(),
        "Slider_Page": (context) => const Slider_Page(),
      },
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final assetsAudioPlayer = AssetsAudioPlayer();

  @override
  void initState() {
    super.initState();
    assetsAudioPlayer.stop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("App"),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              child: const Text("Audio Player"),
              onPressed: () {
                Navigator.of(context).pushNamed("AudioPlayerPage");
              },
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              child: const Text("Video Player"),
              onPressed: () {
                Navigator.of(context).pushNamed("Video_Player_Page");
              },
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              child: const Text("Slider Page"),
              onPressed: () {
                Navigator.of(context).pushNamed("Slider_Page");
              },
            ),
          ],
        ),
      ),
    );
  }
}
